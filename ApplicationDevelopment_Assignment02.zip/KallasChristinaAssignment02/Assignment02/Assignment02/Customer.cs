﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment02
{
    class Customer : Person
    {
        // Additional variables
        private int customerNumber;
        private bool mailingList;

        // Creating the constructor
        public Customer(string firstName, string lastName, string address,
            string phoneNumber, int customerNumber, bool mailingList)
            : base(firstName, lastName, address, phoneNumber) // constructor call
        {
            CustomerNumber = customerNumber;
            MailingList = mailingList;
        }

        // Creating the properties of the extra variables
        public int CustomerNumber
        {
            get
            {
                return customerNumber;
            }
            set
            {
                if (value > 0)
                {
                    customerNumber = value;
                }
                else
                {
                    customerNumber = 99999;
                    Console.WriteLine("Customer number should be a positive integer value.");
                }

            }
        }

        public bool MailingList
        {
            get
            {
                return mailingList;
            }
            set
            {
                mailingList = value;
            }
        }


        // Creating the new DisplayData() method
        public override void DisplayData()
        {
            Console.WriteLine($"|------------------------------------------------------------|");
            Console.WriteLine($"|                          Customer                          |");
            Console.WriteLine($"|------------------------------------------------------------|");
            Console.WriteLine(String.Format($"| {"Customer Number",-20}|{CustomerNumber,38}|"));
            Console.WriteLine($"|------------------------------------------------------------|");
            Console.WriteLine(String.Format($"| {"Last Name",-20}|{LastName,-38}|"));
            Console.WriteLine($"|------------------------------------------------------------|");
            Console.WriteLine(String.Format($"| {"First Name",-20}|{FirstName,-38}|"));
            Console.WriteLine($"|------------------------------------------------------------|");
            Console.WriteLine(String.Format($"| {"Address",-20}|{Address,-38}|"));
            Console.WriteLine($"|------------------------------------------------------------|");
            Console.WriteLine(String.Format($"| {"Phone Number",-20}|{PhoneNumber,38}|"));
            Console.WriteLine($"|------------------------------------------------------------|");
            if (mailingList == true)
            {
                Console.WriteLine(String.Format($"| {"Mailing List",-20}|{"Yes",-38}|"));
            }
            else
            {
                Console.WriteLine(String.Format($"| {"Mailing List",-20}|{"No",-38}|"));
            }
            Console.WriteLine($"|------------------------------------------------------------|");
            Console.WriteLine();
        }
    }
}
