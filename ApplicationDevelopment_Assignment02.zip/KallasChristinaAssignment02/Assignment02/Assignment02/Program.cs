﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment02
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("What is your customer number?");
            int customerNumber = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("What is your first name?");
            string fName = Console.ReadLine();

            Console.WriteLine("What is your last name?");
            string lName = Console.ReadLine();

            Console.WriteLine("What is your adress?");
            string adress = Console.ReadLine();

            Console.WriteLine("What is your phone number?");
            string phoneNumber = Console.ReadLine();

            Person calculator = new Person(fName, lName, adress, phoneNumber);
            calculator.DisplayData();

            Console.WriteLine("Would you like to be part of our mailing list?" +
                "Please only enter Y for yes or N for no.");
            string mailList = Console.ReadLine();
            string mailListBool = "";
            if (mailList == "Y" || mailList == "y")
            {
                mailListBool = "true";
            }
            else if (mailList == "N" || mailList == "n")
            {
                mailListBool = "false";
            }
            else
            {
                Console.WriteLine("Your answer to our mailing list is invalid.");
            }
            bool mailingList = Convert.ToBoolean(mailListBool);



            Customer calculator2 = new Customer(fName, lName, adress, phoneNumber, customerNumber, mailingList);
            calculator2.DisplayData();

            Console.WriteLine("What is the amount you purchased for?");
            decimal purchaseAmount = Convert.ToDecimal(Console.ReadLine());

            PreferredCustomer calculator3 = new PreferredCustomer(fName, lName, adress, phoneNumber, customerNumber, mailingList, purchaseAmount);
            calculator3.DisplayData();

        }
    }
}
