﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment02
{
    class Person
    {
        // Declaring the variables
        private string firstName;
        private string lastName;
        private string address;
        private string phoneNumber;

        // Creating the constructor
        public Person(string firstname, string lastname, string address, string phonenumber)
        {
            FirstName = firstname;
            LastName = lastname;
            Address = address;
            PhoneNumber = phonenumber;
        }

        //Creating Properties
        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }

        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }

        public string Address
        {
            get { return address;  }
            set { address = value;  }
        }

        public string PhoneNumber
        {
            get { return phoneNumber;  }
            set { phoneNumber = value;  }
        }

        // DisplayData() method to print out the table
        public virtual void DisplayData()
        {
            Console.WriteLine($"|------------------------------------------------------------|");
            Console.WriteLine($"|                          PERSON                            |");
            Console.WriteLine($"|------------------------------------------------------------|");
            Console.WriteLine(String.Format($"| {"Last Name",-20}|{LastName,-38}|"));
            Console.WriteLine($"|------------------------------------------------------------|");
            Console.WriteLine(String.Format($"| {"First Name",-20}|{FirstName,-38}|"));
            Console.WriteLine($"|------------------------------------------------------------|");
            Console.WriteLine(String.Format($"| {"Address",-20}|{Address,-38}|"));
            Console.WriteLine($"|------------------------------------------------------------|");
            Console.WriteLine(String.Format($"| {"Phone Number",-20}|{PhoneNumber,38}|"));
            Console.WriteLine($"|------------------------------------------------------------|");
            Console.WriteLine();
        }
    }
}
