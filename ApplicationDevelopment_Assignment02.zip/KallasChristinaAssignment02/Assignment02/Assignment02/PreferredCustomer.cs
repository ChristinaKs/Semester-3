﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment02
{
    class PreferredCustomer : Customer //change filename within VS -- not windows file explorer
    {
        // Creating Additional Variables
        private decimal purchaseAmount;
        private int discountLevel;

        // Creating constructor
        public PreferredCustomer(string lastName, string firstName, string address, string phoneNumber,
            int customerNumber, bool mailingList, decimal purchaseAmount)
            : base(lastName, firstName, address, phoneNumber, customerNumber, mailingList)
        {
            PurchaseAmount = purchaseAmount;
            DiscountLevel = 25; //25 is randomized - but when purchaseAmount is set, it will adjust itaeld - it does not matter what we assign to it 
        }

        // Creating properties
        public decimal PurchaseAmount
        {
            get
            {
                if (purchaseAmount > 0)
                {
                    return purchaseAmount;
                }
                else
                {
                    return purchaseAmount = 0;
                }
            }
            set
            {
                purchaseAmount = value;
                if (purchaseAmount < 0)
                {
                    Console.WriteLine("Customer purchases amount should be a positive value.");
                }
            }
        }


        public int DiscountLevel
        {
            get
            {
                if (PurchaseAmount >= 500 && PurchaseAmount < 1000)
                {
                    return 5;
                }
                else if (PurchaseAmount >= 1000 && PurchaseAmount < 1500)
                {
                    return 6;
                }
                else if (PurchaseAmount >= 1500 && PurchaseAmount < 2000)
                {
                    return 7;
                }
                else if (PurchaseAmount >= 2000)
                {
                    return 10;
                }
                return discountLevel;
            }

            set
            {
                discountLevel = value;
            }
        }


        // Creating the new DisplayData() method
        public override void DisplayData()
        {
            Console.WriteLine($"|------------------------------------------------------------|");
            Console.WriteLine($"|                      Preferred Customer                    |");
            Console.WriteLine($"|------------------------------------------------------------|");
            Console.WriteLine(String.Format($"| {"Customer Number",-20}|{CustomerNumber,38}|"));
            Console.WriteLine($"|------------------------------------------------------------|");
            Console.WriteLine(String.Format($"| {"Last Name",-20}|{LastName,-38}|"));
            Console.WriteLine($"|------------------------------------------------------------|");
            Console.WriteLine(String.Format($"| {"First Name",-20}|{FirstName,-38}|"));
            Console.WriteLine($"|------------------------------------------------------------|");
            Console.WriteLine(String.Format($"| {"Address",-20}|{Address,-38}|"));
            Console.WriteLine($"|------------------------------------------------------------|");
            Console.WriteLine(String.Format($"| {"Phone Number",-20}|{PhoneNumber,38}|"));
            Console.WriteLine($"|------------------------------------------------------------|");
            if (MailingList == true)
            {
                Console.WriteLine(String.Format($"| {"Mailing List",-20}|{"Yes",-38}|"));
            }
            else
            {
                Console.WriteLine(String.Format($"| {"Mailing List",-20}|{"No",-38}|"));
            }
            Console.WriteLine($"|------------------------------------------------------------|");
            Console.WriteLine(String.Format($"| {"Purchase Amount",-20}|{PurchaseAmount,38}|"));
            Console.WriteLine($"|------------------------------------------------------------|");
            Console.WriteLine(String.Format($"| {"Discount Level",-20}|{(float) DiscountLevel / 100,38:P}|"));
            Console.WriteLine($"|------------------------------------------------------------|");
            Console.WriteLine();
        }
    }
}
