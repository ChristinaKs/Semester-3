/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment02;
import java.util.*;

/**
 *
 * @author kalla
 */
public class Assignment02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        // Problem 01 - Given an integer List nums sorted in non-decreasing order, 
            // return an array of the squares of each number sorted in non-decreasing order
        
        // create the List
        ArrayList<Integer> nums = new ArrayList(Arrays.asList(-4, -1, 0, 3, 10));
        
        // Create a new List for the result
        ArrayList<Integer> result = new ArrayList(Arrays.asList());
        
        // iterate through the array and square each number
        for(int num : nums){
            result.add(num * num);
        }
        
        // sort the array
        Collections.sort(result);
        
        System.out.println(result); //print the final result
        
        /* */
        /* */
        /* */
        
        // Problem 02 - Problem 01 but with O(n) approach
        
        // Create the List
        ArrayList<Integer> nums2 = new ArrayList(Arrays.asList(-4, -1, 0, 3, 10));
        
        // Create a new List for the result
        ArrayList<Integer> result2 = new ArrayList(Arrays.asList());
        
        // Create necessary variables for the probelm
        int leftIndex = 0;
        int rightIndex = nums2.size() - 1;
        int i = nums2.size() - 1;
        
        // Change ArrayList to array
        int[] numbs2 = nums2.stream().mapToInt(j -> j).toArray();
        int[] results2 = nums2.stream().mapToInt(j -> j).toArray();
        
        while(rightIndex >= leftIndex){
            if(Math.abs(numbs2[rightIndex]) > Math.abs(numbs2[leftIndex])){
                results2[i] = numbs2[rightIndex] * numbs2[rightIndex];
                rightIndex--;
            } else {
                results2[i] = numbs2[leftIndex] * numbs2[leftIndex];
                leftIndex++;
            }
            i--;
        }
        System.out.println(Arrays.toString(results2));
    
    
        /* */
        /* */
        /* */
        
    
        // Problem 03 - move all 0s in an integer list to the end while maintaining 
            // the regular order of the other elements without making a copy
        
        // create the list
        ArrayList<Integer> nums3 = new ArrayList(Arrays.asList(0, 1, 0, 3, 12));
        
        // Create necessary variables for the  method
        int max = nums3.size() - 1;
        
        // iterate through the array and sawp elements at indez zero with i
        for(int k = max; k >=0; k--) {
            if(nums3.get(k) == 0) {
                // found a zero, so loop forwards from here
                for(int l = k; l < max; l++) {
                    if(nums3.get(l + 1) == 0 || l == max) {
                        // either at the end of the array, or we've run into another zero near the end
                        break;
                    }
                    else {
                        // bubble up the zero we found one element at a time to push it to the end
                        int temp = nums3.get(l + 1);
                        nums3.set(l + 1,nums3.get(l));
                        nums3.set(l, temp);
                    }
                }
            }
        }
        
        // print result
        System.out.println(nums3);
        
    
        /* */
        /* */
        /* */
        
        
        // Problem 04- Problem 03 but with less steps
        
        // Create the List
        ArrayList<Integer> nums4 = new ArrayList(Arrays.asList(0, 1, 0, 3, 12));
        
        // Create necessary variables for the  method
        int counter = 0;
        int n = nums4.size();
        
        for(int m = 0; m < n; m++){
            if(nums4.get(m) != 0){
                nums4.set(counter++, nums4.get(m));
            }
        }
        
        while(counter < n){
            nums4.set(counter++, 0);
        }
        
        System.out.println(nums4);
        
    
        /* */
        /* */
        /* */
        
        
        // Problem 05 - Given two sorted integer lists nums1 and nums2, merge nums2 into nums1 
            // as one sorted array. The number of elements initialized in nums1 
            // and nums2 are m and n respectively. You may assume that nums1 has 
            // a size equal to m + n such that it has enough space to hold 
            // additional elements from nums2. 
            
            
        // Create both lists
        List<Integer> numbers1 = Arrays.asList(1,2,3,0,0,0);
        int o = 3;
        List<Integer> numbers2 = Arrays.asList(2,5,6);
        int p = 3;

        // iterate to merge
        for(int q = 0; q < p; q++){
            numbers1.set(o + q, numbers2.get(q));
        }
        
        // turn it into an Array
        int[] numbers = numbers1.stream().mapToInt(r -> r).toArray();
        
        // sort it 
        Arrays.sort(numbers);
        
        System.out.println(Arrays.toString(numbers));
        
    
        /* */
        /* */
        /* */
        
        
        // Problem 06 - Problem 05 but with no sorting method
        List<Integer> numbers3 = Arrays.asList(1,2,3,0,0,0);
        int x = 3;
        List<Integer> numbers4 = Arrays.asList(2,5,6);
        int z = 3;
        
        // Create necessary variables for this problem
        int idx = x + z - 1;
        int idx2 = x - 1, s = z - 1;
        
        // iterate to sort and merge
        while (idx >= 0) {
            if (idx2 >= 0 && s >= 0) {
                if (numbers3.get(idx2) > numbers4.get(s)) { // pick idx2
                    numbers3.set(idx--, numbers3.get(idx2--));
                } else {
                    numbers3.set(idx--, numbers2.get(s--));
                }
            } else if (idx2 >= 0) {
                numbers3.set(idx--, numbers3.get(idx2--));
            } else { // s >= 0
                numbers3.set(idx--, numbers4.get(s--));
            }
        }
        
        // transform into an array to print
        int[] numbersFinal = numbers3.stream().mapToInt(r -> r).toArray();
        
        System.out.println(Arrays.toString(numbersFinal));
    }
}