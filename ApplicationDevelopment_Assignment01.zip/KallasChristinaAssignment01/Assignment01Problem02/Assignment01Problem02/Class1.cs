﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment01Problem02
{
    class HealthProfile
    {
        private string firstName;
        private string lastName;
        private int yearOfBirth;
        private float weightInPounds;
        private float heightInInches;
        private int currentYear;

        // Constructor for the HealthProfile
        public HealthProfile(string firstname, string lastname, int dob, float heightininches, float weightinpounds, int currentyear)
        {
            FirstName = firstname;
            LastName = lastname;
            YearOfBirth = dob;
            HeightInInches = heightininches;
            WeightInPounds = weightinpounds;
            CurrentYear = currentyear;
        }

        // Creating properties
        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }
        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }
        public int YearOfBirth
        {
            get { return yearOfBirth; }
            set
            {
                if (value > 0)
                    yearOfBirth = value;
                else
                    Console.WriteLine($"Birth year value must be a positive integer.");
            }
        }
        public float HeightInInches
        {
            get { return heightInInches; }
            set
            {
                if (value > 0)
                    heightInInches = value;
                else
                    Console.WriteLine($"Height value must be a positive integer.");
            }
        }
        public float WeightInPounds
        {
            get { return weightInPounds; }
            set
            {
                if (value > 0)
                    weightInPounds = value;
                else
                    Console.WriteLine($"Weight value must be a positive integer.");
            }
        }
        public int CurrentYear
        {
            get { return currentYear; }
            set
            {
                if (value > 0)
                    currentYear = value;
                else
                    Console.WriteLine($"Current year value must be a positive integer.");
            }
        }

        //Person`s age property calculations
        public int PatientAge
        {
            get { return CurrentYear - YearOfBirth; }
            //set { PatientAge = value; }
        }

        //Maximum Heart rate calculations
        public int MaxHeartRate
        {
            get { return 220 - PatientAge; }
            //set { MaxHeartRate = value; }
        }

        //Target heart rate calculations
        public string TargetHeartRate
        {
            get
            {
                double minRate = MaxHeartRate * (0.5);
                double maxRate = MaxHeartRate * (0.85);
                return $"{minRate} - {maxRate}";

            }
            set { TargetHeartRate = value; }
        }

        //BMI calculator
        public float BmiCalculator
        {
            get
            {
                float Bmi = (WeightInPounds * 703) / (HeightInInches * HeightInInches);
                return Bmi;
            }
            //set { BmiCalculator = value; }
        }

        public string BmiConverter
        {
            get
            {
                if(BmiCalculator < 18.5)
                {
                    return "Underweight";
                } else if(BmiCalculator >= 18.5 && BmiCalculator < 24.9)
                {
                    return "Normal";
                } else if(BmiCalculator >= 24.9 && BmiCalculator < 29.9)
                {
                    return "Overweight";
                }
                else
                {
                    return "Obese";
                }
            }
            //set { BmiConverter = value;  }
        }
    }
}
