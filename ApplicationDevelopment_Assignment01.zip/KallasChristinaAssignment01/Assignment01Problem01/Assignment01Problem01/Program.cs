﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment01Problem01
{
    class Program
    {
        static void Main(string[] args)
        {
/*
            HeartRates calculator = new HeartRates("", "", 0, 0);

            Console.WriteLine("What is your first name?");
            calculator.FirstName = Console.ReadLine();

            Console.WriteLine("What is your last name?");
            calculator.LastName = Console.ReadLine();

            Console.WriteLine("What is your year of birth?");
            calculator.YearOfBirth = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("What is the current year?");
            calculator.CurrentYear = Convert.ToInt32(Console.ReadLine());
*/

            Console.WriteLine("What is your first name?");
            string fName = Console.ReadLine();

            Console.WriteLine("What is your last name?");
            string lName = Console.ReadLine();

            Console.WriteLine("What is your year of birth?");
            int bYear = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("What is the current year?");
            int cYear = Convert.ToInt32(Console.ReadLine());

            HeartRates calculator = new HeartRates(fName, lName, bYear, cYear);

            string FinalizedName = String.Format($"|Patient's name                     |{calculator.LastName}, {calculator.FirstName,-10}|");
            string FinalizedBirthYear = String.Format($"|Patient's birth year               |{calculator.YearOfBirth, 18}|");
            string FinalizedAge = String.Format($"|Patient's age                      |{calculator.PatientAge, 18}|");
            string FinalizedMaxHeartRate = String.Format($"|Patient's maximum heart rate       |{calculator.MaxHeartRate, 18}|");
            string FinalizedTargetHeartRate = String.Format($"|Patient's target heart rate        |{calculator.TargetHeartRate, 18}|");

            Console.WriteLine("|------------------------------------------------------|");
            Console.WriteLine($"|               PATIENT HEART RATE RECORD              |");
            Console.WriteLine("|------------------------------------------------------|");
            Console.WriteLine(FinalizedName);
            Console.WriteLine("|------------------------------------------------------|");
            Console.WriteLine(FinalizedBirthYear);
            Console.WriteLine("|------------------------------------------------------|");
            Console.WriteLine(FinalizedAge);
            Console.WriteLine("|------------------------------------------------------|");
            Console.WriteLine(FinalizedMaxHeartRate);
            Console.WriteLine("|------------------------------------------------------|");
            Console.WriteLine(FinalizedTargetHeartRate);
            Console.WriteLine("|------------------------------------------------------|");

        }
    }
}
