﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment01Problem01
{
    public class HeartRates
    {
        private string firstName;
        private string lastName;
        private int yearOfBirth;
        private int currentYear;

        //Constructor
        public HeartRates(string firstname, string lastname, int dob, int currentyear)
        {
            FirstName = firstname;
            LastName = lastname;
            YearOfBirth = dob;
            CurrentYear = currentyear;
        }

        // Creating properties
        public string FirstName 
        { 
          get {return firstName;}
          set{ firstName = value;}
        }

        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }
    
        public int YearOfBirth
        {
            get { return yearOfBirth; }
            set 
            {
                if (value > 0)
                    yearOfBirth = value;
                else
                    Console.WriteLine($"Birth year value must be a positive integer.");
            }
        }
        public int CurrentYear
            {
            get { return currentYear; }
            set
            {
                if (value > 0)
                    currentYear = value;
                else
                    Console.WriteLine($"Current year value must be a positive integer.");
            }
        }

    //Person`s age property calculations
    public int PatientAge
        {
            get { return CurrentYear - YearOfBirth; }
           // set { PatientAge = value; }
        }

        //Maximum Heart rate calculations
        public int MaxHeartRate
        {
            get { return 220 - PatientAge; }
            //set { MaxHeartRate = value; }
        }

        //Target heart rate calculations
        public string TargetHeartRate
        {
            get
            {
                double minRate = MaxHeartRate * (0.5);
                double maxRate = MaxHeartRate * (0.85);
                return $"{minRate} - {maxRate}";

            }
            //set { TargetHeartRate = value; }
        }
    }
}
